Jones, Paul

Changed directory and added Common Folder

Added a fourth case in the switch

Initialized a color buffer

